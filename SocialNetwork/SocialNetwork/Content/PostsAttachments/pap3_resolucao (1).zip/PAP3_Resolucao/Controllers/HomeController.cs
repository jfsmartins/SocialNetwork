﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PAP3_Resolucao.Models;

namespace PAP3_Resolucao.Controllers
{
    public class HomeController : Controller
    {
        DataClasses1DataContext db = new DataClasses1DataContext();;
        public ActionResult Index()
        {
            return View(db.alunos);
        }

        public ActionResult About()
        {
            return View();
        }

        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public PartialViewResult Edit(int id)
        {
            return PartialView(db.alunos.Single(x => x.id == id));
        }

        [HttpPost]
        public PartialViewResult Edit(int id, FormCollection collection)
        {
            aluno al = db.alunos.Single(x => x.id == id);

            al.nome = collection["nome"];
            al.numero = collection["numero"];

            db.SubmitChanges();

            return PartialView("Lista", al);
        }
    }
}
